<?php


extract($_POST);

$conn=mysqli_connect("localhost","root","","data");
$sql="CREATE TABLE allusers(uname VARCHAR(10),friend VARCHAR(30),country VARCHAR(20),age INT(2),school VARCHAR(20),interests VARCHAR(20),hobbies VARCHAR(20),contact INT(10))";
mysqli_query($conn,$sql);

$sql="INSERT INTO allusers (uname,friend,country,age,school,interests,hobbies,contact) VALUES ('$uname','','','','','','','' )";
mysqli_query($conn,$sql);
$conn->close();  


$conn=mysqli_connect("localhost","root","");
$sql="CREATE DATABASE pics";
mysqli_query($conn,$sql);
$conn->close();

$db = mysqli_connect("localhost", "root", "", "pics");
$sql="CREATE TABLE images(id INT(10),image VARCHAR(50),text TEXT)";
mysqli_query($db,$sql);

 if (isset($_POST['upload'])) 
  
    {

    $image = $_FILES['image']['name'];

  	$target = "images/".basename($image);

   

  	// Get text
  

  	// image file directory
  	
  	$sql = "INSERT INTO images (image,text) VALUES ('$image','$uname')";
  	// execute query
  	mysqli_query($db, $sql);

  


  	move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }


$conn=mysqli_connect("localhost","root","");
$sql="CREATE DATABASE data";
mysqli_query($conn,$sql);
$conn->close();

// once u create the db, close it and open the conn in the created db

$conn=mysqli_connect("localhost","root","","data");
$sql="CREATE TABLE user(uname VARCHAR(20),pwd VARCHAR(10))";
mysqli_query($conn,$sql);

$sql="INSERT INTO user(uname,pwd) VALUES ('$uname','$pwd')";
mysqli_query($conn,$sql);
$conn->close();
?>



<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		h2{
			
			color:#f0fcd0;
			font-size: 35px;
		}

		a{
			color: #f0fcd0;
			font-size: 25px;
			font-weight: bold
		}
	</style>
	<title></title>
</head>
<body background="image.jpg">
	<h2 align="center">You have successfully signed Up!!</h2>
	<br><br><br>
<a href="signin.php"><center>Click here to Sign In</center></a>
<br><br><br>
<a href="index.html"><center>Click here to go back to Home</a><center></a>
</script>
</body>
</html>

