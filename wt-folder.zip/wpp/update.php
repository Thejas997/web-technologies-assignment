<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="new-nav.css">
	<style type="text/css">

body{
    margin: 0;
    padding: 0;
    background: url(image.jpg);
    background-size: cover;
    
    font-family: sans-serif;
}

.login-box{
    width: 900px;
    height: 1010px;
    background: rgba(0, 0, 0, 0.6);
    color: #fff;
    top: 110%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
}
h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}
.login-box p{
    margin: 0;
    padding: 0;
    font-weight: bold;
}
.login-box input{

    width: 100%;
    margin-bottom: 100px;
}

.login-box input{
  height:17px;
  border: 0;
  width: calc(100%  - 2px);
  margin-left:0px;
  box-shadow: 0px 0px 0px 0px #ebebeb, 0px 0px 0px 0px #ebebeb;
  -webkit-transition: box-shadow 0.6s;
  transition: box-shadow 0.s;
}

.login-box input[type="text"]:focus {
  outline: none ;
  box-shadow: -8px 10px 0px -9px #4EA6EA, -10px 10px 10px -6px #4EA6EA;
}


.login-box input[type="text"]
{
    border: none;
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 40px;
    color: #fff;
    font-size: 16px;


}

h2{
    color: #f1f8ed;
    font-family:"serif";
    font-size:40px;
    font-spacing:
}

.login-box input[type="submit"]
{
	width: 200px;
	height: 50px;
    border: none;
    outline: none;
    background: #1c8adb;
    color: #fff;
    font-size: 18px;
    border-radius: 10px;
}
.login-box input[type="submit"]:hover
{
    cursor: pointer;
    background: red;
    transition: 0.5s;
    color: #000;
}
	</style>

	
</head>


<body>

<header>
        <h1>INFO<span>SHARE</span></h1>
        <nav>
            <ul>
                <li><a href="after-signin.php">Home</a></li>
                <li><a href="friend.php">Add Friend</a></li>
                <li><a href="image.php"s>My Images</a></li>
                <li><a href="vid.php">My Videos</a></li>
                <li><a href="view.php">View Friends</a></li>
                 <li><a href="index.html">LOGOUT</a></li>
            </ul>
        </nav>
    </header>
<br><br><br>

<h2 id="upd"><center>Please Update Your Information</center></h2>

<div class="login-box">

	<form action="" method="post">
		
		COUNTRY<input type="text" name="country">
		AGE<input type="text" name="age">
		SCHOOL/COLLEGE NAME<input type="text" name="school">
		YOUR INTERESTS<input type="text" name="interests">
		HOBBIES<input type="text" name="hobbies">
		CONTACT NO<input type="text" name="contact">
		<center><input type="submit" name="submit" value="Update"></center>
	</form>
</div>

<?php
extract($_POST);
session_start();
$sess_un=$_SESSION['name'];
if(isset($_POST['submit']))
{
$conn=mysqli_connect("localhost","root","","data");

$sql="UPDATE allusers SET uname='$sess_un',friend='',country='$country',age=$age,school='$school',interests='$interests',hobbies='$hobbies',contact=$contact WHERE uname='$sess_un'  ";
mysqli_query($conn,$sql);
echo "<script>alert('Information Updated Successfully!!');
window.location='after-signin.php';
</script>";

$conn->close();  


}

?>
</body>
</html>