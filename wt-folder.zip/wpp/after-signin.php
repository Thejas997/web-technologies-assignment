<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" type="text/css" href="new-nav.css">
	
    <title></title>
    <style>
        #welcome{
        margin-left:100px;
		font-family: georgia;
		color:#f0fcd0;
		font-size:35px;

	}


#abv{

    position: absolute;
    top: 58px;
    right: 0px;

}


h4{

   text-align:left;

}


h2{
    color:wheat;
    font-family:sans-serif;
    /*padding-left: 500px;
    */text-decoration: ;
}


h3{
    text-align: center;

}

#ah{
    
    
}


img{

        width: 300px;}

#dac{
    
    text-align:center;
}
#da{
    display:inline-block;
    width:500px;
    color:white;
    border: 10px solid rgba(0,0,0,.5);
    background:rgba(0,0,0,0.3);
}
    </style>

</head>

<body background="image.jpg">
<div>
<header>
        <h1>INFO<span>SHARE</span></h1>
        <nav>
            <ul>
                <li><a href="update.php">Update Info</a></li>
                <li><a href="friend.php">Add Friend</a></li>
                <li><a href="image.php">My Images</a></li>
                <li><a href="vid.php">My Videos</a></li>
                <li><a href="view.php">View Friends</a></li>
                 <li><a href="index.html">LOGOUT</a></li>
            </ul>
        </nav>
    </header>
<br><br><br>

<?php
	session_start();	
     $sess= $_SESSION['name'];



 
$conn=mysqli_connect("localhost","root","","data");

$sql="SELECT * from allusers WHERE uname='$sess' ";       
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);      

if($row['country']=='')
{
    echo "<script>alert('Please update you info first!!');
    window.location='update.php';  
    </script>";
}







	if(isset($_SESSION['name']))
{

	echo "<h4 id=\"welcome\">Welcome ".$_SESSION['name'];				
    echo "</h4>";
    
    echo "<br>";
}
else
	echo "you must be logged in to access this page";

   


  $db = mysqli_connect("localhost", "root", "", "pics");
  $sql="SELECT * FROM images WHERE text='$sess'   ";
  $result=mysqli_query($db,$sql);
    echo"<div id='abv'>"; 
 while ($row = mysqli_fetch_array($result))
     {
        
         echo "<img src='images/".$row['image']." '>";
    }
    echo "</div>";


echo "<font face=\"sans-serif\" size=\"15px\" color=\"white\"><center>YOUR INFORMATION:</center></font>";
echo "<br>";
echo "<br>";

$conn=mysqli_connect("localhost","root","","data");

$sql="SELECT * from allusers WHERE uname='$sess' ";       
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
echo "<div id=\"dac\">";     
echo "<div id=\"da\">";
echo "<h2>COUNTRY :</h2>";
//echo "<br>";
echo "<h3>".$row['country']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>AGE :</h2>";
//echo "<br>";
echo "<h3>".$row['age']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>SCHOOL/COLLEGE : </h2>";
//echo "<br>";
echo "<h3>".$row['school']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>INTERESTS :</h2>";
//echo "<br>";
echo "<h3>".$row['interests']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>HOBBIES :</h2>";
//echo "<br>";
echo "<h3>".$row['hobbies']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>CONTACT :</h2>";
//echo "<br>";
echo "<h3>".$row['contact']."</h3>";
echo "<br>";
echo "<br>";    

echo "</div>";
echo "</div>";

$conn->close();


?>


</body>
</html>
