<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="videonew.css">
	<link rel="stylesheet" type="text/css" href="new-nav.css">
	<style type="text/css">

	body{
	
	background: url(image.jpg);

	background-size: cover;
    background-position: center;
    font-family: sans-serif;
	}

	div a{
		padding-right: 230px;
		padding-left: 290px;
		
			
	}



h3{
	text-align: center;

}
h2{
	color:wheat;
}


#a{
	color: white;
	padding-left: 450px;
	text-decoration: none;

}
#dac{
    
    text-align:center;
}
#da{
    display:inline-block;
    width:500px;
    color:white;
    border: 10px solid rgba(0,0,0,.5);
    background:rgba(0,0,0,0.3);
}

img{
	width: 300px;
}
   

	</style>
	<title></title>
</head>

<body>



<header>
        <h1>INFO<span>SHARE</span></h1>
        <nav>
            <ul>
                <li><a href="after-signin.php">Home</a></li>
                <li><a href="update.php">Update Info</a></li>
                <li><a href="friend.php">Add Friend</a></li>
                <li><a href="image">My Images</a></li>
                <li><a href="vid.php">My Videos</a></li>
                <li><a href="index.html">LOGOUT</a></li>
                
            </ul>
        </nav>
    </header>
<br><br>

<center><h2>YOUR FRIEND INFORMATION: </h2></center>
<br><br><br>


<?php

extract($_GET);



$conn=mysqli_connect("localhost","root","","data");

$sql="SELECT * from allusers WHERE uname='$friend' ";		
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);		
echo "<div id=\"dac\">";     
echo "<div id=\"da\">";
echo "<h2>COUNTRY :</h2>";
//echo "<br>";
echo "<h3>".$row['country']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>AGE :</h2>";
//echo "<br>";
echo "<h3>".$row['age']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>SCHOOL/COLLEGE : </h2>";
//echo "<br>";
echo "<h3>".$row['school']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>INTERESTS :</h2>";
//echo "<br>";
echo "<h3>".$row['interests']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>HOBBIES :</h2>";
//echo "<br>";
echo "<h3>".$row['hobbies']."</h3>";
echo "<br>";
echo "<br>";

echo "<h2>CONTACT :</h2>";
//echo "<br>";
echo "<h3>".$row['contact']."</h3>";
echo "<br>";
echo "<br>";	

echo "</div>";
echo "</div>";
$conn->close();

?>
<br><br><br><br><br>
<table class="table" width="550" align="center">
<?php


  $db = mysqli_connect("localhost", "root", "", "$friend");
  $sql="SELECT * FROM images";
  $result=mysqli_query($db,$sql);



print"<tr>";
print"<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Description</u> </strong></td>";
print "<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Image </u></strong></td>";
print "<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Image Name </u></strong></td>";

print"</tr>";
    while ($row = mysqli_fetch_array($result))
     {


      print "<tr>\n";


   print "\t<td style=\"color:white;text-align:center\" >\n";
    echo $row['text'];
  print "</td >\n";

  print "\t<td style=\"color:white;align:center\" >\n";
  ;
 echo "<img src='images/".$row['image']." '>";
 
  print "</td >\n";



   print "\t<td style=\"color:white;text-align:center\" >\n";

   echo $row['image'] ;
  print "</td >\n";
  
  print "</tr >\n";

    }

print "</table>\n";
print "</div>";
  
?>


<table class="table" width="550" align="center">

<br><br><br><br><br><br><br>

  <?php
  $db = mysqli_connect("localhost", "root", "","$friend");
  $sql="SELECT * FROM videos";
  $result=mysqli_query($db,$sql);



print"<tr>";
print"<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Description</u> </strong></td>";
print "<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Video </u></strong></td>";
print "<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Video Name </u></strong></td>";

print"</tr>";
    while ($row = mysqli_fetch_array($result))
     {


      print "<tr>\n";


   print "\t<td style=\"color:white;text-align:center\" >\n";
    echo $row['text'];
  print "</td >\n";

  print "\t<td style=\"color:white;align:center\" >\n";
  
 echo "<video width='320' controls> <source src='videos/".$row['image']."' type='video/mp4' >";
 


  print "</td >\n";



   print "\t<td style=\"color:white;text-align:center\" >\n";

   echo $row['image'] ;
  print "</td >\n";
  
  print "</tr >\n";

    }

print "</table>\n";
print "</div>";
  ?>


</script>
</body>
</html>