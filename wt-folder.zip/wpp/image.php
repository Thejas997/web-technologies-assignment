<?php

session_start();
$sess=$_SESSION['name'];

$conn=mysqli_connect("localhost","root","");
$sql="CREATE DATABASE $sess";
mysqli_query($conn,$sql);
$conn->close();

$db = mysqli_connect("localhost", "root", "", $sess);
$sql="CREATE TABLE images(id INT(10),image VARCHAR(50),text TEXT)";
mysqli_query($db,$sql);

 if (isset($_POST['upload'])) 
  
    {

    $image = $_FILES['image']['name'];

  	$target = "images/".basename($image);

   

  	// Get text
  	$text = $_POST['text'];

  	// image file directory
  	
  	$sql = "INSERT INTO images (image, text) VALUES ('$image', '$text')";
  	// execute query
  	mysqli_query($db, $sql);

    echo "<script>alert('Image uploaded successfully');</script>";


  	move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }



 if (isset($_POST['delete']))
 {
  extract($_POST);
  $db = mysqli_connect("localhost", "root", "", $sess);
   $sql="DELETE FROM images WHERE image='$del' ";
   echo "<script>alert('Image deleted successfully');</script>";
   mysqli_query($db, $sql);
 } 

  //$result = mysqli_query($db, "SELECT * FROM images");
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="new-nav.css">
  <link rel="stylesheet" type="text/css" href="videonew.css">
<title>Image Upload</title>
<style type="text/css">
   #content{
   	width: 100%;
   	margin: 20px auto;
   	border: 4px solid #cbcbcb;
   }


   form{
   	width: 50%;
   	margin: 20px auto;
   }
   form div{
   	margin-top: 5px;
   }
/*   #img_div{
   	
    width: 50%;
   	padding: 25px;
   	margin: 25px auto;
   	border: 4px solid #cbcbcb;
   }
*/
/*
   #img_div:after{
   	content: "";
   	display: block;
   	clear: both;
   }
*/
   img{
   	float: left;
   	margin: 5px;
   	width: 300px;
   	height: 140px;
   }
</style>
</head>
<body >


<header>
        <h1>INFO<span>SHARE</span></h1>
        <nav>
            <ul>
                <li><a href="after-signin.php">Home</a></li>
                <li><a href="friend.php">Add Friend</a></li>
                 <li><a href="update.php">Update Info</a></li>
                <li><a href="vid.php">My Videos</a></li>
                <li><a href="view.php">View Friends</a></li>
                 <li><a href="index.html">LOGOUT</a></li>
            </ul>
        </nav>
    </header>
    <br><br>
  <div class="form">
  <form method="post" action="image.php" enctype="multipart/form-data">
    <i style="font-size:25px"> <i> <u><strong>Upload your Image :</strong></u><br>    <br><br>
    
      
    <input  class="input" type="text" placeholder="Type some Description of image:" id="text" name="text"><br><br>

    <div>
      <input type="file" name="image" onclick='fun()' class="button" >
        <br><br>
    </div>
    <div>
      
    </div>
    <div>
      <input type="submit" name="upload" value="Upload Image" id='abc' disabled="true" class="button" >
      <br><br><br>
      <i style="font-size:25px"> <i> <u><strong>Delete your Image:</strong></u><br> 
      <br><br><input type="text" name="del" class="input" placeholder="Enter the name of the image to be deleted:">
      <br><br><br><input type="submit" value="Delete" name="delete" class="button">
    </div>
  </form>
</div>
<br><br>
<table class="table" width="550" align="center">

  <?php
  $db = mysqli_connect("localhost", "root", "", $sess);
  $sql="SELECT * FROM images";
  $result=mysqli_query($db,$sql);



print"<tr>";
print"<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Description</u> </strong></td>";
print "<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Image </u></strong></td>";
print "<td style=\"text-align:center\"><strong style=\"color:white\" ><u> Image Name </u></strong></td>";

print"</tr>";
    while ($row = mysqli_fetch_array($result))
     {


      print "<tr>\n";


   print "\t<td style=\"color:white;text-align:center\" >\n";
    echo $row['text'];
  print "</td >\n";

  print "\t<td style=\"color:white;align:center\" >\n";
  ;
 echo "<img src='images/".$row['image']." '>";
 
  print "</td >\n";



   print "\t<td style=\"color:white;text-align:center\" >\n";

   echo $row['image'] ;
  print "</td >\n";
  
  print "</tr >\n";

    }

print "</table>\n";
print "</div>";
  ?>
<script type="text/javascript">
  function fun()
  {

document.querySelector('#abc').removeAttribute("disabled");
document.querySelector('#abc').style.backgroundColor='#00cc33';

   }
</script>
</table>
</body>
</html>
