<html>
<head>
    <title>Login-Form</title>
    <link rel="stylesheet" type="text/css" href="new-nav.css">
    <style type="text/css">
body{
    margin: 0;
    padding: 0;
    background: url(image.jpg);
    background-size: cover;
    
    font-family: sans-serif;
}

.login-box{
    width: 320px;
    height: 420px;
    background: rgba(0, 0, 0, 0.6);
    color: #fff;
    top: 55%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
}
.avatar{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    top: -50px;
    left: calc(50% - 50px);
}
h1{
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
}
.login-box p{
    margin: 0;
    padding: 0;
    font-weight: bold;
}
.login-box input{

    width: 100%;
    margin-bottom: 40px;
}

.login-box input{
  height:17px;
  border: 0;
  width: calc(100%  - 2px);
  margin-left:0px;
  box-shadow: 0px 0px 0px 0px #ebebeb, 0px 0px 0px 0px #ebebeb;
  -webkit-transition: box-shadow 0.6s;
  transition: box-shadow 0.s;
}

.login-box input[type="text"]:focus {
  outline: none ;
  box-shadow: -8px 10px 0px -9px #4EA6EA, -10px 10px 10px -6px #4EA6EA;
}


.login-box input[type="password"]:focus {
  outline: none ;
  box-shadow: -8px 10px 0px -9px #4EA6EA, -10px 10px 10px -6px #4EA6EA;
}


.login-box input[type="email"]:focus {
  outline: none ;
  box-shadow: -8px 10px 0px -9px #4EA6EA, -10px 10px 10px -6px #4EA6EA;
}

.login-box input[type="text"], input[type="password"],input[type="email"]
{
    border: none;
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 40px;
    color: #fff;
    font-size: 16px;


}

.login-box input[type="submit"]
{
    border: none;
    outline: none;
    height: 40px;
    background: #1c8adb;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
}
.login-box input[type="submit"]:hover
{
    cursor: pointer;
    background: red;
    transition: 0.5s;
    color: #000;
}

.login-box a{
    text-decoration: none;
    font-size: 14px;
    color: #fff;
}
.login-box a:hover
{
    color: #39dc79;
}
    </style>   

   </head>
    <body>

<header>
        <h1>INFO<span>SHARE</span></h1>
        <nav>
            <ul>

                <li><a href="index.html">HOME</a></li>
                <li><a href="signup.html">SIGN UP</a></li>
                <li><a href="signin.php">SIGN IN</a></li>
                
            </ul>
        </nav>
    </header>


    <div class="login-box">
    <img src="ishare.png" class="avatar">
       
            <form method="post" action="">
            <p>Username</p>
            <input type="text" name="username" placeholder="Enter Username" required="" autofocus="">
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password" required="">
            <input type="submit" name="submit" value="Login">
            <a href="#">Forgot Password?</a>    
            </form>
    </div>

<?php
extract($_POST);
$flag=0;
if(isset($_POST['submit']))
{
        $conn=mysqli_connect("localhost","root","","data");
        $sql="SELECT uname,pwd from user";      
        $res=mysqli_query($conn,$sql);
        while($row=mysqli_fetch_assoc($res))         
        {
        if($password == $row['pwd'] && $username==$row['uname'])
                {

                    session_start();                
                    $_SESSION['name']=$username;                 
                    $flag=1;
                    break;
                }
       }
       $conn->close();  
    

if($flag)
	{	
		echo "
		<script>
				location.href='after-signin.php'
				</script>";

	}
else
	{
		echo " <script>
    	alert('Username or Password is wrong!!');
    		</script>";
	}
}
?>


    </body>
</html>
